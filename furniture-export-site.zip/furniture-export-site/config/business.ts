// Business model, positioning, and market facts. Changing this should never
// require touching component code — see docs/CLAUDE.md §13.

export const businessConfig = {
  businessModel: "asset-light", // trading/export — no owned factory; production via vetted supplier partners
  positioning: "Bali furniture sourcing partner",
  targetMarkets: ["USA", "Australia", "Europe"], // from your brief — confirm or expand
  buyerTypes: ["Interior Designers", "Hotels", "Retailers", "Distributors"], // from your brief
  services: [], // TODO — e.g. custom sizing, private label, container consolidation, QC inspection
  sellingPoints: [], // TODO
  sourcingProcess: [
    // DRAFT — a standard trading-company flow. Replace with the actual steps from
    // your Notion "Checklist Operasional (Master)" once ready to share.
    "Inquiry & Brief",
    "Supplier Matching & Quote",
    "Sample Approval",
    "Production & QC",
    "Export & Shipping",
  ],
} as const;
