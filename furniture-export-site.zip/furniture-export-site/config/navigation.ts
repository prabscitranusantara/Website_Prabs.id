// Primary + footer navigation. Level 1 — edit directly; components must never hardcode links.

export const navigationConfig = {
  primary: [
    { label: "Collections", href: "/collections" },
    { label: "Why Bali", href: "/why-bali" },
    { label: "Sourcing Process", href: "/sourcing" },
    { label: "Projects", href: "/projects" },
    { label: "Contact", href: "/contact" },
  ],
  cta: { label: "Request Catalog", href: "/contact" }, // DRAFT — align with features.showCatalogDownload
  footer: {
    columns: [
      {
        title: "Company",
        links: [
          { label: "Why Bali", href: "/why-bali" },
          { label: "Sourcing Process", href: "/sourcing" },
          { label: "Projects", href: "/projects" },
        ],
      },
      { title: "Catalog", links: [{ label: "Collections", href: "/collections" }] },
      { title: "Contact", links: [{ label: "Get in Touch", href: "/contact" }] },
    ],
  },
} as const;
