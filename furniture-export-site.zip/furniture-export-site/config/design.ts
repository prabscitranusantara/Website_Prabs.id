// Design tokens — the single source for spacing/type/radius/shadow across every component.
// Level 2 (Design Adjustment). Full rationale in docs/DESIGN.md.
//
// Tailwind v4 note: these values are mirrored into app/globals.css as @theme custom
// properties (Tailwind v4 is CSS-first — there is no tailwind.config.ts). This file stays
// the source of truth for anything components read directly in TS/JS.

export const designConfig = {
  colors: {
    background: "#FBFAF7",
    foreground: "#231A13",
    muted: "#8A7F70",
    accent: "#8C6A3F",
    border: "#DDD4C4",
  },
  typography: {
    headingFont: "Fraunces",     // warm editorial serif with real texture — not the generic AI high-contrast serif
    bodyFont: "Public Sans",     // humane grotesk, reads well for long spec/product descriptions
    dataFont: "IBM Plex Mono",   // dimensions/CBM/product codes — echoes a packing-list/manifest, matches how the catalog is already tracked
    headingWeight: 500,
    bodyWeight: 400,
  },
  spacing: {
    section: "clamp(4rem, 8vw, 8rem)",
    container: "min(1200px, 92vw)",
    card: "1.5rem",
  },
  radius: {
    small: "4px",
    medium: "10px",
    large: "20px",
  },
  shadows: {
    card: "0 1px 2px rgba(35,26,19,0.06), 0 8px 24px rgba(35,26,19,0.06)",
    elevated: "0 4px 8px rgba(35,26,19,0.08), 0 20px 48px rgba(35,26,19,0.12)",
  },
} as const;
