// Never hardcode contact details in components — always import from here.

export const contactConfig = {
  email: "prabscitranusantara@gmail.com",
  whatsapp: "6200000000000", // ⚠ all-zeros pattern — double-check this is your real number before launch. Stored without "+" to match wa.me link format; read via NEXT_PUBLIC_WHATSAPP_NUMBER, see .env.example
  phone: "6200000000000", // same number as WhatsApp — update if these should differ
  address: "TODO", // a city/region is enough for a public B2B site — avoid a precise street address unless you want one shown
  instagram: "https://instagram.com/prabs.id",
  linkedin: "TODO", // not provided — skip if you don't use LinkedIn
} as const;
