// Global SEO defaults. Any page may override title / description / image / canonical.

export const seoConfig = {
  title: "Prabs | Bali Furniture Sourcing & Export",
  description:
    "Sourcing and exporting premium furniture from vetted Bali production partners for interior designers, hotels, retailers, and distributors worldwide.", // DRAFT
  keywords: [
    "Bali furniture export",
    "wholesale rattan furniture",
    "furniture sourcing Indonesia",
    "B2B furniture supplier Bali",
  ],
  ogImage: "/og/default.jpg", // TODO: not yet supplied
  canonical: "https://example.com", // TODO: confirm domain
} as const;
