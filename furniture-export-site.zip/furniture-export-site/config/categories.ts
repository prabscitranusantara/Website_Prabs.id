// Starter categories from your brief. Your real product catalog already lives in
// Notion (173 products across 3 supplier partners) — once that's ready to share,
// replace this with the real category breakdown rather than guessing further.

export const categories = [
  { id: "seating", name: "Seating", enabled: true },
  { id: "tables", name: "Tables", enabled: true },
  { id: "cabinets", name: "Cabinets", enabled: true },
] as const;
