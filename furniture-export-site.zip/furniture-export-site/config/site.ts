// Core site identity & environment-level settings.
// Level 1 (Quick Adjustment) — safe to edit directly, no component changes needed.

export const siteConfig = {
  name: "Prabs", // confirmed — public-facing name; full entity is PRABS CITRA NUSANTARA
  tagline: "Bali furniture sourcing, without the risk of buying sight unseen", // DRAFT — replace
  description:
    "Asset-light furniture sourcing and export partner connecting interior designers, hotels, retailers, and distributors to vetted Bali production partners.", // DRAFT — replace
  url: "https://example.com", // TODO: confirm domain
  language: "en", // primary language at launch — see docs/CLAUDE.md §19 for future ID/JP/DE support
  market: "global",
  currency: "USD", // pricing is inquiry-based (see config/business.ts) — currency mainly for freight/quote context
} as const;
