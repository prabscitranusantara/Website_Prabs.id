// Homepage section order. The renderer reads this, drops disabled sections,
// sorts by order, and renders what's left — sections can be added, removed, or
// reordered here without touching the homepage itself. Carried over from your brief.

export const sections = [
  { id: "hero", enabled: true, order: 1 },
  { id: "featuredCollection", enabled: true, order: 2 },
  { id: "whyBali", enabled: true, order: 3 },
  { id: "sourcingProcess", enabled: true, order: 4 },
  { id: "projects", enabled: true, order: 5 },
  { id: "cta", enabled: true, order: 6 },
] as const;
