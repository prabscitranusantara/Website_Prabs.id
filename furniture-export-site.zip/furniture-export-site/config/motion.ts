// Centralized motion settings — see docs/CLAUDE.md §08 for intensity semantics.
// Carried over verbatim from your brief. Respect prefers-reduced-motion at the
// consuming component, not here — see docs/DESIGN.md.

export const motionConfig = {
  enabled: true,
  intensity: "subtle" as "none" | "subtle" | "medium" | "expressive",
  duration: 0.6,
  ease: "easeOut",
  pageTransitions: true,
  scrollReveal: true,
  parallax: true,
  hoverEffects: true,
} as const;
