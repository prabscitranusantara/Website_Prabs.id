// Visual + verbal brand identity. Pairs with design.ts (tokens) and docs/DESIGN.md (rationale).
// Level 1 (colors/logo) / Level 2 (palette strategy — see DESIGN.md) Adjustment.

export const brandConfig = {
  name: "Prabs", // confirmed — keep in sync with siteConfig.name
  logo: "/brand/logo.svg", // TODO: not yet supplied
  logoMark: "/brand/mark.svg", // small mark for favicon / mobile nav — optional

  // v1 proposal — grounded in the subject (teak, brass hardware, natural fibre) rather than
  // a generic "furniture site" palette. See docs/DESIGN.md for the reasoning. Adjust freely.
  colors: {
    primary: "#33261C",   // deep teak
    secondary: "#EDE7DA", // warm limestone/sisal neutral
    background: "#FBFAF7",
    foreground: "#231A13",
    accent: "#8C6A3F",    // aged brass
  },
} as const;
