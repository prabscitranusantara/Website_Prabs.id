// Feature flags — toggle functionality without deleting components.
// Carried over verbatim from your brief.

export const features = {
  showProjects: true,
  showTestimonials: false,
  showWhatsApp: true,
  showCatalogDownload: true,
  showCustomFurniture: true,
  showNewsletter: false,
  enableParallax: true,
  enablePageTransitions: true,
} as const;
