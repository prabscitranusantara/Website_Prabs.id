// Product data model. Kept separate from /config since this is expected to eventually
// migrate to a DB/CMS (see docs/ARCHITECTURE.md — Database & CMS Ready).
//
// Field names are aligned to your existing internal product catalog (Category, Product
// Name, Product Code, Length, Width, Diameter, Seat Height, Total Height, Weight, CBM)
// so this can eventually sync from that source instead of being maintained twice.
//
// Intentionally excluded: Harga Beli / Harga Jual / Margin. Those are internal cost
// fields from your ops catalog and should never ship to a public site — this also
// matches the brief's own inquiry-based model (no visible pricing).

export interface Product {
  id: string;
  slug: string;
  name: string;
  code: string;
  category: string; // matches an id in config/categories.ts
  description: string;
  images: string[];
  materials: string[];
  dimensions: {
    length?: number;      // cm
    width?: number;       // cm
    diameter?: number;    // cm
    seatHeight?: number;  // cm
    totalHeight?: number; // cm
    weight?: number;      // kg
    cbm?: number;
  };
  finish: string;
  customization: boolean;
  inquiryEnabled: boolean;
}

export const products: Product[] = [
  // TODO — populate from your Notion "Katalog Produk Furniture" database (173 products)
];
