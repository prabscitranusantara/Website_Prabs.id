// Tailwind v4 is CSS-first — this is the only build config it needs.
// (No tailwind.config.ts: theme tokens live in app/globals.css via @theme.)
const config = {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};

export default config;
