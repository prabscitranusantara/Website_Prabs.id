# Furniture Export Site — Scaffold (v1)

Config/content/docs layer for a modular, config-driven B2B furniture sourcing & export site.
No app pages or components yet, by design — see `docs/DECISIONS.md` for what's still open
before that starts.

## What this is
- `config/` — every business/brand/design decision the site depends on, in one typed place
- `content/` — marketing copy, kept separate from UI so copy can change without touching code
- `data/products.ts` — the product data model (schema only, no products yet)
- `docs/` — `CLAUDE.md` (operating rules), `ARCHITECTURE.md`, `DESIGN.md`, `CONTENT.md`,
  `DECISIONS.md`

Read `docs/DECISIONS.md` first — it lists exactly what's confirmed vs. still a placeholder.

## Running it
This was generated in a sandbox with no network access, so nothing here has been installed
or run yet.

```
npm install
npm run dev
```

If you continue this project in **Claude Code**, it can install dependencies, run the dev
server, and iterate on the actual pages/components live — better suited to that than this
chat for the next (structural/visual) phase.

## Conventions used throughout
- `// TODO: ...` — a required value only you can supply (name, contact info, real data)
- `// DRAFT` — placeholder copy written to unblock scaffolding; expected to be rewritten
