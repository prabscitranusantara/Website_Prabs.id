// Page copy for /contact. Actual contact values live in config/contact.ts — this file is copy only.

export const contactContent = {
  title: "Get in touch", // DRAFT
  body: "", // TODO
} as const;
