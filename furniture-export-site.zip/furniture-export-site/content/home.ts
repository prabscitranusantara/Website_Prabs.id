// Marketing copy for the homepage. Kept separate from UI components (see docs/CLAUDE.md §14).
// Everything below is DRAFT — replace before launch.

export const homeContent = {
  hero: {
    eyebrow: "Bali Furniture Sourcing", // DRAFT
    title: "Your sourcing partner for premium Bali furniture", // DRAFT
    description:
      "We connect interior designers, hotels, retailers, and distributors to vetted production partners across Bali — without the risk of sourcing sight unseen.", // DRAFT
  },
  whyBali: {
    title: "Why source from Bali", // DRAFT
    body: "", // TODO
  },
} as const;
