// TODO — pull the real steps from your Notion "Checklist Operasional (Master)".

export const sourcingContent = {
  title: "How sourcing works", // DRAFT
  steps: [], // TODO — see config/business.ts sourcingProcess for a draft starting list
} as const;
