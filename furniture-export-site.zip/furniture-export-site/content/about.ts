// TODO — draft once positioning/tone is confirmed.

export const aboutContent = {
  title: "About us", // DRAFT
  body: "", // TODO — asset-light trading model, supplier network, experience, etc.
} as const;
