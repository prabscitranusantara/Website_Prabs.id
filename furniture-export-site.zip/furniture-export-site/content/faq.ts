export const faqContent: { question: string; answer: string }[] = [
  // TODO
];
