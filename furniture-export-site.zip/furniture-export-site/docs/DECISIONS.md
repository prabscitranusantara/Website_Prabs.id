# DECISIONS.md

## 2026-08-12 — Initial scaffold

**Framework**: Next.js 16 (App Router) + TypeScript + Tailwind CSS v4 + Motion + shadcn/ui.
Not an open choice — implied by the brief's own conventions (server components,
`NEXT_PUBLIC_WHATSAPP_NUMBER`, `motion/react`, 21st.dev/shadcn compatibility). Confirmed
Next.js 16 / Tailwind v4 are current stable via web search before scaffolding, since a
training-only guess would likely have produced an outdated `tailwind.config.js`-based setup.

**Scope of this pass**: `/config`, `/content`, `/data`, `/docs`, plus `app/globals.css` and
root build config only. No `/app` pages or `/components` yet — per the brief's own
"do not begin destructive changes until the architecture is clear," that's the next phase,
gated on the open items below.

**Carried over verbatim from the client's brief** (treated as real decisions, not
placeholders, since they were given as concrete values rather than `...`):
`businessConfig.targetMarkets`, `buyerTypes`, `positioning`; all of `motionConfig`;
all of `features`; the `sections` order; the starter `categories` list.

**Grounded in known business context** (not invented): asset-light trading model (no owned
factory, production via supplier partners); product dimension fields in
`data/products.ts` aligned to the client's existing internal catalog columns.

**Explicit exclusion**: public `Product` schema omits purchase price / selling price /
margin, which exist in the client's internal ops catalog. A public sourcing site should not
expose cost or margin data.

**Open items — need client input before Level 3 (structural/visual) work starts**:
- Brand/company name (this is a B2B export/trading brand — distinct from the three named
  supplier partners) + logo
- Domain, email, WhatsApp number, phone, Instagram/LinkedIn handles
- Real product category list and the actual product data (both live in the client's Notion
  workspace already)
- Real sourcing-process steps (from the Checklist Operasional Master in Notion)
- v1 palette/type direction in `DESIGN.md` — sanity-check once a real name/logo exists

## 2026-08-13 — Brand + contact confirmed

**Confirmed by client**: public-facing name "Prabs" (full entity: PRABS CITRA NUSANTARA) →
`config/site.ts`, `config/brand.ts`, `config/seo.ts`. Email
`prabscitranusantara@gmail.com`, Instagram `prabs.id` → `config/contact.ts`.

**Flagged, not blocking**: the WhatsApp/phone number submitted (`6200000000000`) is an
all-zeros pattern and is very likely a placeholder — stored as given, marked with a ⚠
comment in `config/contact.ts` pending confirmation. Same number used for both WhatsApp and
phone since only one was given.

**Still deferred by client's own choice**: product catalog stays "wired later" rather than
exported now — `data/products.ts` remains schema-only. Categories and sourcing-process steps
also left as the v1 drafts from the previous pass (client had nothing to add yet).

**Still open**: domain, phone (if different from WhatsApp), address, LinkedIn.

## 2026-08-13 — Static homepage preview added

Added `preview/homepage-demo.html` — a standalone, no-build HTML/CSS mockup of the homepage
(hero, featured collection, why-Bali, sourcing steps, contact) using the confirmed brand
tokens and draft copy. This is NOT part of the Next.js app — it's a fast way to sanity-check
the v1 design direction before Level 3 (real pages/components) work starts. Delete once the
real homepage exists.
