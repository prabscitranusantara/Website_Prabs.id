# DESIGN.md

## Why not the default AI-furniture-site look
The common AI-generated defaults right now are (a) warm cream + high-contrast serif +
terracotta accent, (b) near-black + one acid accent, (c) hairline-rule broadsheet layout.
All three would read as templated on a premium B2B sourcing brand, so this palette and type
pairing are grounded in the actual subject instead — see below. Everything here is a v1
proposal (Level 2 / Design Adjustment) — cheap to change via `config/design.ts`, not a fixed
decision.

## Palette (v1 — grounded, not final)
| Token | Hex | Why |
|---|---|---|
| primary | `#33261C` | deep teak — the region's signature export hardwood, not a generic brand color |
| secondary | `#EDE7DA` | warm limestone/sisal neutral — greyer and cooler than the common "cream" default |
| background | `#FBFAF7` | near-white, warm cast |
| foreground | `#231A13` | near-black warm brown, for body text |
| accent | `#8C6A3F` | aged brass — echoes furniture hardware/fittings, not terracotta/clay |

## Typography
- **Heading — Fraunces**: warm editorial serif with real optical texture at display sizes.
- **Body — Public Sans**: humane grotesk, holds up for longer spec/product descriptions.
- **Data — IBM Plex Mono**: for product codes, dimensions, CBM. This is the one deliberate
  "signature" idea for later: presenting product specs like a shipping manifest / packing
  list (monospaced, tabular) — because that's literally how this catalog is already tracked
  internally (Length, Width, Diameter, Seat Height, Total Height, Weight, CBM). Worth
  prototyping once real product data is in.

## Tokens
Spacing, radius, and shadow values are in `config/design.ts` and mirrored into
`app/globals.css`. Radius is intentionally modest (4 / 10 / 20px) — a premium B2B catalog
site should read as precise, not soft/consumer-app rounded.

## Motion
Default intensity `subtle`, matching the brief. `prefers-reduced-motion` is handled globally
in `app/globals.css` — components shouldn't need to re-implement that check.

## Open design decisions
- Brand name + logo not yet supplied — palette/type can be sanity-checked once real wordmark
  exists.
- No hero layout chosen yet (centered / split / editorial / etc.) — do this once real hero
  copy and at least placeholder product photography exist to design around.
- Theme system (§18 of CLAUDE.md — e.g. a future "Dark Luxury" variant) not started; current
  tokens are the only theme.
