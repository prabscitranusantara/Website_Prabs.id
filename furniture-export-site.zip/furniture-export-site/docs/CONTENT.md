# CONTENT.md

## Structure
```
content/home.ts       hero copy, "why Bali" intro
content/about.ts      about/positioning copy
content/sourcing.ts   sourcing-process page copy (steps list is TODO)
content/contact.ts    /contact page copy (not contact *values* — those are config/contact.ts)
content/faq.ts        FAQ entries (empty — TODO)
```

## Status
Everything currently in `/content` is either `DRAFT` (placeholder copy written to unblock
scaffolding — expected to be rewritten) or `TODO` (left empty on purpose rather than
inventing specifics). None of it should be treated as approved copy.

## Real source for product content
The client's product catalog (173 products, Category / Product Name / Photo / Code /
dimensions / CBM) already exists in Notion, sourced from a spreadsheet. Once ready to share,
that becomes the real source for `data/products.ts` and `config/categories.ts` — this repo
should not need new copywriting for that part, just a data import.

## Voice / tone
Not yet defined. Should reflect a B2B trade partner speaking to professional buyers (interior
designers, hotels, retailers, distributors) — precise and credible rather than
consumer-retail — but this hasn't been confirmed with the client.
