# CLAUDE.md — Operating Rules for This Project

This project is a **design system + website engine**, not a static site. Source: adapted
from the client's own master brief (Aug 2026). Full history of decisions in `DECISIONS.md`.

## Master principle
Everything listed below must be adjustable without rebuilding the site: brand, logo, colors,
typography, layout, spacing, radius, hero, CTA, navigation, product categories, product data,
business positioning, target markets, testimonials, projects, contact info, WhatsApp, social,
animation/motion intensity, SEO, language, currency, footer, section order.
If a value is likely to change later, it lives in `/config`, `/content`, or `/data` — never
hardcoded inside a component.

## Single source of truth
```
/config    site, brand, design, navigation, seo, contact, motion, features, business, sections, categories
/content   home, about, sourcing, contact, faq  (marketing copy — kept separate from UI, §14)
/data      products.ts (product catalog — kept separate since it's DB/CMS-bound later)
```
Components consume these values. Never duplicate a config value inside a component.

## Three adjustment levels
- **Level 1 — Quick**: logo, colors, hero title, CTA, WhatsApp number, animation on/off →
  edit a config file only.
- **Level 2 — Design**: typography, card radius, spacing, hero layout, image ratio, animation
  intensity, nav style → edit `config/design.ts` + `DESIGN.md`.
- **Level 3 — Structural**: new page, remove/reorder section, new product category, new
  conversion flow → modular components + feature config.

## Design tokens
Colors / typography / spacing / radius / shadows live in `config/design.ts` and are mirrored
into `app/globals.css` (`@theme` block — Tailwind v4 is CSS-first, there is no
`tailwind.config.ts`). If design changes, edit the tokens, not each component.

## Hero
Hero is config-driven (`enabled`, `eyebrow`, `title`, `description`, `primaryCTA`,
`secondaryCTA`, `image`, `imagePosition`, `layout`, `overlay`, `animation`,
`animationIntensity`). Supported layouts: centered, split, fullscreen, editorial,
image-left, image-right, minimal. Don't rewrite the Hero component to switch layouts unless
structurally necessary.

## Sections
`config/sections.ts` drives the homepage: read config → drop disabled → sort by `order` →
render. Add/remove/reorder sections there, not in the page file.

## Feature flags
`config/features.ts`. Turn functionality on/off without deleting components.

## Motion
`config/motion.ts`. Intensity: `none | subtle | medium | expressive` (default `subtle`).
Always respect `prefers-reduced-motion` (see `app/globals.css`) — disable non-essential
animation when it's set. Use the `motion` package (`import { motion } from "motion/react"`),
values sourced from `motionConfig`, never hardcoded per-component.

## 21st.dev / external components
May be used, but the site must never depend on one. When importing: inspect → adapt to the
design system → strip unneeded deps → normalize typography/spacing/color/animation → confirm
responsive + accessible. It becomes part of this project's own component system. If it
conflicts with `DESIGN.md`, `DESIGN.md` wins.

## Product system
Data-driven — never hand-build individual product pages. Shape: `id, slug, name, code,
category, description, images, materials, dimensions, finish, customization, inquiryEnabled`.
See `data/products.ts` for the full interface (dimensions aligned to the client's existing
Notion catalog fields). **Internal cost/margin fields are never part of the public schema.**
Adding a product = adding data, not writing a page.

## Category system
`config/categories.ts` — `{ id, name, enabled }`. New categories shouldn't require touching
core components.

## Business configuration
`config/business.ts` — model, positioning, target markets, buyer types, services, selling
points, sourcing process. If positioning changes, the architecture stays intact.

## Content system
Marketing copy lives in `/content`, never buried in a component, so copywriting can change
without restructuring the frontend.

## Contact system
`config/contact.ts` — never hardcode contact details in a component. WhatsApp reads from
`NEXT_PUBLIC_WHATSAPP_NUMBER` (see `.env.example`).

## SEO
`config/seo.ts` provides defaults; any page may override `title` / `description` / `image` /
`canonical`.

## Responsive
One responsive system — no separate mobile build. Centralize container widths, breakpoints,
spacing, type scale, grid behavior.

## Theme system
Design tokens should make re-theming possible (e.g. a future "Dark Luxury" or "Minimal
Scandinavian" pass) primarily by changing tokens, not rewriting components.

## Language
Architected for multilingual later (Indonesian, Japanese, German are plausible next
languages). English at launch. Don't hardcode language-specific assumptions into components.

## Database / CMS ready
Static data now; `data/products.ts` and `/content` use clean interfaces so a later move to
Supabase/Postgres/a headless CMS doesn't require rebuilding the UI.

## Documentation system
`CLAUDE.md` (this file, rules) · `DESIGN.md` (design system + rationale) · `CONTENT.md`
(content structure) · `DECISIONS.md` (decision log) · `ARCHITECTURE.md` (technical
architecture). Update the relevant doc whenever that layer changes.

## Change management
Classify every request first — Content / Design / UX / Component / Business / Feature /
Architecture / SEO / Performance — then make the **smallest** appropriate change.
"Change the hero color" touches a design token or hero config only — not product cards,
footer, nav, or the contact form.

## Change impact analysis
Before a major change, name: what changes, what depends on it, what must stay the same.
E.g. "make the site dark" touches tokens, hero, nav, cards, footer, forms, images, contrast,
buttons, accessibility — work through it systematically, don't swap colors ad hoc.

## Safe adjustment mode
Inspect current implementation → identify dependencies → identify tokens → identify affected
components → make the smallest coherent change → check for regressions. Never rewrite the
whole site for a small change.

## Visual audit mode
"Make it more premium" is not "add effects." Evaluate typography, whitespace, image quality,
composition, grid, hierarchy, color, contrast, CTA, micro-interactions — then make the
minimum change needed.

## A/B test ready
Conversion components (hero, CTA, product card) should support variants via config
(`heroVariant: "A"`, `ctaVariant: "primary"`) without duplicating the site.

## Analytics ready
Centralize event tracking behind one abstraction rather than sprinkling
provider-specific code. Candidate events: `hero_cta_click`, `collection_view`,
`product_view`, `product_inquiry`, `whatsapp_click`, `catalog_download`, `contact_submit`.

## Security
No API keys/credentials/secrets in code — environment variables only, documented in
`.env.example`, never committed as real values.

## Performance
Adjustable ≠ bloated. Prefer server components, optimized images, lazy loading, minimal
dependencies, code splitting. Don't add a library because it looks interesting.

## Accessibility
Every adjustable option must stay accessible: color changes can't destroy contrast,
typography changes can't destroy readability, animation changes can't create a11y problems.

## AI decision rule
When uncertain, don't invent — use existing config/design/content/architecture, or create a
clearly-marked placeholder (see the `TODO` / `DRAFT` convention used throughout this repo).

## Command priority
1. Explicit user instruction 2. Business requirements 3. Accessibility 4. Performance
5. Design system 6. Existing architecture 7. Default assumptions.
Never sacrifice business accuracy for visual polish.

## Final rule
Change one thing → the right part changes — without breaking other sections, rebuilding the
site, creating inconsistency, or duplicating code.
