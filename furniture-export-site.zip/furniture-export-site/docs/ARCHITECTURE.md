# ARCHITECTURE.md

## Stack (proposed, not yet installed)
- **Next.js 16** (App Router, current stable — see release notes checked Aug 2026)
- **React 19**
- **TypeScript**
- **Tailwind CSS v4** — CSS-first: theme tokens live in `app/globals.css` under `@theme`,
  there is no `tailwind.config.ts`. `postcss.config.mjs` just wires in `@tailwindcss/postcss`.
- **Motion** (`motion/react`, formerly Framer Motion) for animation
- **shadcn/ui** components as needed, adapted into this design system per `CLAUDE.md` §09
- **lucide-react** for icons

This matches what the original brief already implies (server components, `motion/react`,
`NEXT_PUBLIC_*` env convention, shadcn/21st.dev compatibility) — it wasn't an open choice.

## What exists in this pass
```
config/    site, brand, design, navigation, seo, contact, motion, features, business,
           sections, categories — all typed, all real where the brief/business context
           gave real values, clearly marked TODO/DRAFT elsewhere
content/   home, about, sourcing, contact, faq — minimal stubs, mostly TODO
data/      products.ts — the Product type + empty array
app/       globals.css — Tailwind v4 theme + reduced-motion handling
docs/      this file, CLAUDE.md, DESIGN.md, CONTENT.md, DECISIONS.md
package.json, tsconfig.json, postcss.config.mjs, .env.example
```

## What deliberately does NOT exist yet
No `app/layout.tsx`, `app/page.tsx`, or `/components`. Building the actual Hero, section
renderer, product cards, and nav is Level 3 structural work — per the brief's own
"do not begin destructive changes until the architecture is clear," that's next, once brand
name, contact details, and a real category/product list are confirmed (see DECISIONS.md).

## Data flow
`config/*` and `content/*` are the only things components should import for anything that
might change. `data/products.ts` is separated from `/config` specifically because it's
expected to move to a database — see Database/CMS-ready below.

## Database / CMS ready
`Product` in `data/products.ts` is a clean interface, not a hardcoded structure baked into
components. When ready, the same interface can be served from Supabase/Postgres or a
headless CMS instead of a static array — components consuming it shouldn't need to change.
The natural real source for the initial data is the client's own Notion product catalog.

## Environment / sandbox note
This scaffold was generated in a sandboxed environment with no network access, so `npm
install` / `next dev` haven't been run or verified here. Dependency versions in
`package.json` are intentionally left as `latest` rather than pinned, since Next.js/React/
Tailwind have shipped several security patch releases in 2026 — run `npm install` in your
own environment (or continue this project in Claude Code, which can install, run a dev
server, and iterate live) and it will resolve current patched versions.
